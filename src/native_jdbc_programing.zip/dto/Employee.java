package native_jdbc_programing.dto;

public class Employee {
	private int empNo;
	private String empName;
	private Title title;    //int가 아닌 Title로 적어주는게 포인트. (DB연동을 배운사람은)
	private Employee manager;
	private int slary;
	private Department dept;
	
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Employee(int empNo) {
		this.empNo = empNo;
	}


	public Employee(int empNo, String empName, Title title, Employee manager, int slary, Department dept) {
		this.empNo = empNo;
		this.empName = empName;
		this.title = title;
		this.manager = manager;
		this.slary = slary;
		this.dept = dept;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Title getTitle() {
		return title;
	}
	public void setTitle(Title title) {
		this.title = title;
	}
	public Employee getManager() {
		return manager;
	}
	public void setManager(Employee manager) {
		this.manager = manager;
	}
	public int getSlary() {
		return slary;
	}
	public void setSlary(int slary) {
		this.slary = slary;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	@Override
	public String toString() {
		return String.format("Employee [empNo=%s, empName=%s, title=%s, manager=%s, slary=%s, dept=%s]", empNo, empName,
				title, manager, slary, dept);
	}
	
}
