package native_jdbc_programing.dao.impl;

import java.util.List;

import native_jdbc_programing.dao.TitleDao;
import native_jdbc_programing.dto.Title;

public class TitleDaoImpl implements TitleDao {
	private static final TitleDaoImpl instance = new TitleDaoImpl();
	

	public static TitleDaoImpl getInstance() {
		return instance;
	}

	@Override
	public List<Title> selectTitleByAll() {
		// TODO Auto-generated method stub
		String sql = "select tno, tname from title";
		return null;
	}

	@Override
	public Title selectTitleByNo(Title title) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insertTitle(Title title) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateTitle(Title title) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteTitle(int titleNo) {
		// TODO Auto-generated method stub
		return 0;
	}

}
